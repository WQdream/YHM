function __vite__mapDeps(indexes) {
  if (!__vite__mapDeps.viteFileDeps) {
    __vite__mapDeps.viteFileDeps = ["assets/index-CxtoupTc.js","assets/index-DFEDjKuf.js","assets/index-DWzy0YyM.css","assets/plugin-vueexport-helper-DlAUqK2U.js","assets/index-CLh2JCQE.css","assets/tagsView-BxHnrcCE.js","assets/sortable.esm-BS5toX6s.js","assets/tagsView-Ci7djzdr.css"]
  }
  return indexes.map((i) => __vite__mapDeps.viteFileDeps[i])
}
import{d as r,u as m,s as f,y as l,e as o,f as p,j as v,F as t,H as T,G as g,K as a,_ as n}from"./index-DFEDjKuf.js";import{_ as h}from"./plugin-vueexport-helper-DlAUqK2U.js";const y={class:"layout-navbars-container"},C=r({name:"layoutNavBars"}),V=r({...C,setup(x){const c=a(()=>n(()=>import("./index-CxtoupTc.js"),__vite__mapDeps([0,1,2,3,4]))),_=a(()=>n(()=>import("./tagsView-BxHnrcCE.js"),__vite__mapDeps([5,1,2,6,3,7]))),i=m(),{themeConfig:u}=f(i),d=l(()=>{let{layout:e,isTagsview:s}=u.value;return e!=="classic"&&s});return(e,s)=>(o(),p("div",y,[v(t(c)),d.value?(o(),T(t(_),{key:0})):g("",!0)]))}}),k=h(V,[["__scopeId","data-v-6cf86195"]]);export{k as default};
